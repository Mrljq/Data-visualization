
import json

class SourceDataDemo:

    def __init__(self):
        self.title = '基于flask的中国经济大数据可视化展板'
        self.counter = {'name': '2023年总收入情况(万)', 'value': 568000000}
        self.counter2 = {'name': '2023年总支出情况(万)', 'value': 424000000}
        self.echart1_data = {
            'title': '前七大贸易伙伴（亿美元）',
            'data': [
                {"name": "美国", "value": 48826.08},
                {"name": "日本", "value": 24016.21},
                {"name": "韩国", "value": 23403.53},
                {"name": "中国香港", "value": 23266.63},
                {"name": "中国台湾", "value": 21200.8},
                {"name": "德国", "value": 15195.08},
                {"name": "澳大利亚", "value": 14900.69},
            ]
        }
        self.echart2_data = {
            'title': '省份分布（亿元）',
            'data': [
                {"name": "广东", "value": 129118},
                {"name": "江苏", "value": 122875},
                {"name": "山东", "value": 87435},
                {"name": "浙江", "value": 77715},
                {"name": "河南", "value": 61345},
                {"name": "四川", "value": 56749},
                {"name": "湖北", "value": 53734},
            ]
        }
        self.echarts3_1_data = {
            'title': '在职年龄分布',
            'data': [
                {"name": "16-24岁", "value": 5.5},
                {"name": "25-29岁", "value": 20.5},
                {"name": "30-39岁", "value": 44},
                {"name": "40-49岁", "value": 24.2},
                {"name": "50岁以上", "value": 7.2},
            ]
        }
        self.echarts3_2_data = {
            'title': '新型行业产值',
            'data': [
                {"name": "5G", "value": 6000},
                {"name": "新能源汽车", "value": 3200},
                {"name": "人工智能", "value": 4800},
                {"name": "生物科技", "value": 3000},
                {"name": "云计算", "value": 5000},
                {"name": "私人航天", "value": 2000},
            ]
        }
        self.echarts3_3_data = {
            'title': '经济最活跃行业',
            'data': [
                {"name": "数字经济", "value": 9},
                {"name": "人工智能", "value": 10},
                {"name": "区块链", "value": 8},
                {"name": "供应链", "value": 3},
                {"name": "绿色经济", "value": 5},
                {"name": "云计算", "value": 11},
            ]
        }
        self.echart4_data = {
            'title': 'ios和安卓的市场占有率（%）',
            'data': [
                {"name": "安卓", "value": [52.5, 78.0, 80.70, 81.35, 82.62, 81.2, 82.21, 78.23, 76.74]},
                {"name": "IOS", "value": [18.8, 15.9, 13.62, 14.13, 16.94, 15.87, 14.04, 20.63, 21.46]},
            ],
            'xAxis': ['2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020'],
        }
        self.echart5_data = {
            'title': '经济贡献最大的前十大行业（万亿）',
            'data': [
                {"name": "金融", "value": 26.3},
                {"name": "房地产", "value": 21.2},
                {"name": "制造", "value": 20.7},
                {"name": "科技", "value": 20.3},
                {"name": "批发零售", "value": 18.2},
                {"name": "交通运输", "value": 13.5},
                {"name": "第三产业", "value": 10.7},
                {"name": "第一产业", "value": 10.3},
            ]
        }
        self.echart6_data = {
            'title': '一线城市情况',
            'data': [
                {"name": "浙江", "value": 80, "value2": 20, "color": "10", "radius": ['59%', '70%']},
                {"name": "上海", "value": 70, "value2": 30, "color": "02", "radius": ['49%', '60%']},
                {"name": "广东", "value": 65, "value2": 35, "color": "09", "radius": ['39%', '50%']},
                {"name": "北京", "value": 60, "value2": 40, "color": "24", "radius": ['29%', '40%']},
                {"name": "深圳", "value": 50, "value2": 50, "color": "35", "radius": ['20%', '30%']},
            ]
        }
        self.map_1_data = {
            'symbolSize': 100,
            'data': [
                {'name': '海南', 'value': 239},
                {'name': '浙江', 'value': 231},
                {'name': '广东', 'value': 203},
            ]
        }

    @property
    def echart1(self):
        data = self.echart1_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'series': [i.get("value") for i in data.get('data')]
        }
        return echart

    @property
    def echart2(self):
        data = self.echart2_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'series': [i.get("value") for i in data.get('data')]
        }
        return echart

    @property
    def echarts3_1(self):
        data = self.echarts3_1_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'data': data.get('data'),
        }
        return echart

    @property
    def echarts3_2(self):
        data = self.echarts3_2_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'data': data.get('data'),
        }
        return echart

    @property
    def echarts3_3(self):
        data = self.echarts3_3_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'data': data.get('data'),
        }
        return echart

    @property
    def echart4(self):
        data = self.echart4_data
        echart = {
            'title': data.get('title'),
            'names': [i.get("name") for i in data.get('data')],
            'xAxis': data.get('xAxis'),
            'data': data.get('data'),
        }
        return echart

    @property
    def echart5(self):
        data = self.echart5_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'series': [i.get("value") for i in data.get('data')],
            'data': data.get('data'),
        }
        return echart

    @property
    def echart6(self):
        data = self.echart6_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'data': data.get('data'),
        }
        return echart

    @property
    def map_1(self):
        data = self.map_1_data
        echart = {
            'symbolSize': data.get('symbolSize'),
            'data': data.get('data'),
        }
        return echart


class SourceData(SourceDataDemo):

    def __init__(self):

        super().__init__()
        self.title = '基于flask的中国经济大数据可视化展板'

class CorpData(SourceDataDemo):

    def __init__(self):

        super().__init__()
        with open('corp.json', 'r', encoding='utf-8') as f:
            data = json.loads(f.read())
        self.title = data.get('title')
        self.counter = data.get('counter')
        self.counter2 = data.get('counter2')
        self.echart1_data = data.get('echart1_data')
        self.echart2_data = data.get('echart2_data')
        self.echarts3_1_data = data.get('echarts3_1_data')
        self.echarts3_2_data = data.get('echarts3_2_data')
        self.echarts3_3_data = data.get('echarts3_3_data')
        self.echart4_data = data.get('echart4_data')
        self.echart5_data = data.get('echart5_data')
        self.echart6_data = data.get('echart6_data')
        self.map_1_data = data.get('map_1_data')

class JobData(SourceDataDemo):

    def __init__(self):

        super().__init__()
        with open('job.json', 'r', encoding='utf-8') as f:
            data = json.loads(f.read())
        self.title = data.get('title')
        self.counter = data.get('counter')
        self.counter2 = data.get('counter2')
        self.echart1_data = data.get('echart1_data')
        self.echart2_data = data.get('echart2_data')
        self.echarts3_1_data = data.get('echarts3_1_data')
        self.echarts3_2_data = data.get('echarts3_2_data')
        self.echarts3_3_data = data.get('echarts3_3_data')
        self.echart4_data = data.get('echart4_data')
        self.echart5_data = data.get('echart5_data')
        self.echart6_data = data.get('echart6_data')
        self.map_1_data = data.get('map_1_data')